
-- more expensive license

NDefines.NProduction.LICENSE_EQUIPMENT_BASE_SPEED = -0.45	

-- no land division training xp
NDefines.NMilitary.UNIT_EXPERIENCE_PER_TRAINING_DAY = 0

-- more ahead of time penalty:
-- NDefines.NTechnology.BASE_YEAR_AHEAD_PENALTY_FACTOR = 4

-- can embargo anytime
NDefines.NDiplomacy.EMBARGO_THREAT_THRESHOLD = -1						-- Target-generated threat threshold to allow embargo (affected by modifiers)